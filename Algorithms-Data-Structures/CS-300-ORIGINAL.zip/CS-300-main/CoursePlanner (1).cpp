#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

// Course structure
struct Course {
    string courseNumber;
    string name;
    vector<string> prerequisites;
};

// Global course storage
map<string, Course> courseMap;

// Function to trim whitespace
string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\r\n");
    size_t last = str.find_last_not_of(" \t\r\n");
    return (first == string::npos) ? "" : str.substr(first, last - first + 1);
}

// Load course data from file
void LoadDataStructure(const string& fileName) {
    ifstream file(fileName);
    if (!file.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    courseMap.clear();
    string line;

    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        Course course;

        getline(ss, token, ',');
        course.courseNumber = trim(token);

        getline(ss, token, ',');
        course.name = trim(token);

        while (getline(ss, token, ',')) {
            course.prerequisites.push_back(trim(token));
        }

        courseMap[course.courseNumber] = course;
    }

    file.close();
    cout << "Course data loaded successfully!" << endl;
}

// Print course list alphabetically
void PrintCourseList() {
    if (courseMap.empty()) {
        cout << "Course list is empty. Load data first." << endl;
        return;
    }

    vector<Course> courseList;
    for (auto& pair : courseMap) {
        courseList.push_back(pair.second);
    }

    sort(courseList.begin(), courseList.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
        });

    cout << "\nHere is a sample schedule:" << endl;
    for (const auto& course : courseList) {
        cout << course.courseNumber << ", " << course.name << endl;
    }
}

// Print individual course details
void PrintCourseInfo(const string& courseNumber) {
    string upperCourse = courseNumber;
    transform(upperCourse.begin(), upperCourse.end(), upperCourse.begin(), ::toupper);

    auto it = courseMap.find(upperCourse);
    if (it == courseMap.end()) {
        cout << "Course not found." << endl;
        return;
    }

    Course course = it->second;
    cout << course.courseNumber << ", " << course.name << endl;
    cout << "Prerequisites: ";
    if (course.prerequisites.empty()) {
        cout << "None" << endl;
    }
    else {
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            cout << course.prerequisites[i];
            if (i < course.prerequisites.size() - 1) cout << ", ";
        }
        cout << endl;
    }
}

// Menu
void DisplayMenu() {
    cout << "\n1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
    cout << "What would you like to do? ";
}

// Main
int main() {
    cout << "Welcome to the course planner." << endl;

    int choice;
    string fileName;

    while (true) {
        DisplayMenu();
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid input. Please enter a number." << endl;
            continue;
        }

        switch (choice) {
        case 1:
            cout << "Enter the file name: ";
            cin >> fileName;
            LoadDataStructure(fileName);
            break;
        case 2:
            PrintCourseList();
            break;
        case 3:
            cout << "What course do you want to know about? ";
            cin >> fileName;
            PrintCourseInfo(fileName);
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            return 0;
        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }

    return 0;
}
