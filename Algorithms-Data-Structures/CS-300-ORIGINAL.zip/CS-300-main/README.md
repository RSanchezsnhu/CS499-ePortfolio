# CS-300


**What was the problem you were solving in the projects for this court?**
I was designing a program to load, store, and display a list of courses that needed to be printed out in alphanumerical order and would allow users to search for individual courses and be able to view their prerequisites.

**How did you approach the problem? Consider why data structures are important to understand.**
I analyzed how different data structures would affect the performance. I used pseudocode to outline the logic and then translated it into the solution. Data structures are important to understand because choosing the correct one helped me ensure the program was efficient and meant that the program would not only work but it would also perform well as the amount of data grows.

**How did you overcome any roadblocks you encountered while going through the activities or project?**
I reviewed course materials when I had an issue and even went back to look at examples or previous assignments I had done. I also broke problems down into smaller parts and tested them so it would help me find and fix errors a lot easier.

**How has your work on this project expanded your approach to designing software and developing programs?**
It showed me the importance of selecting the appropriate data structures during the design phase. I also learned that the more I plan with pseudocode the smoother the process is and helps keep everything a lot more organized.

**How has your work on this project evolved the way you write programs that are maintainable, readable, and adaptable?**
I feel like I've learned to write cleaner more readable code thats well organized as well as getting better at writing code comments so my thought process and what the functions do are easier to understand and if there's an issue I can just look at those.
