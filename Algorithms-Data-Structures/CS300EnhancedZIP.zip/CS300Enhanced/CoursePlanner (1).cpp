#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <set>

using namespace std;

// Course structure
struct Course {
    string courseNumber;
    string name;
    vector<string> prerequisites;
};

// Global storage
map<string, Course> courseMap;

// Stores prerequisite relationships
map<string, vector<string>> courseGraph;

// Function to trim whitespace
string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\r\n");

    if (first == string::npos) {
        return "";
    }

    size_t last = str.find_last_not_of(" \t\r\n");
    return str.substr(first, last - first + 1);
}

// Build a graph with course prerequisites
void BuildGraph() {
    courseGraph.clear();

    // Add courses to the graph
    for (const auto& pair : courseMap) {
        courseGraph[pair.first];
    }

    // Connect the prerequisite to the course that needs it
    for (const auto& pair : courseMap) {
        const Course& course = pair.second;

        for (const string& prerequisite : course.prerequisites) {
            if (courseMap.find(prerequisite) != courseMap.end()) {
                courseGraph[prerequisite].push_back(course.courseNumber);
            }
        }
    }
}

// Load course data from file
void LoadDataStructure(const string& fileName) {
    ifstream file(fileName);

    if (!file.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    courseMap.clear();
    courseGraph.clear();

    string line;

    while (getline(file, line)) {
        if (trim(line).empty()) {
            continue;
        }

        stringstream ss(line);
        string token;
        Course course;

        getline(ss, token, ',');
        course.courseNumber = trim(token);

        getline(ss, token, ',');
        course.name = trim(token);

        while (getline(ss, token, ',')) {
            string prerequisite = trim(token);

            if (!prerequisite.empty()) {
                course.prerequisites.push_back(prerequisite);
            }
        }

        if (!course.courseNumber.empty()) {
            courseMap[course.courseNumber] = course;
        }
    }

    file.close();

    BuildGraph();

    cout << "Course data loaded successfully!" << endl;
}

// Print course list alphabetically
void PrintCourseList() {
    if (courseMap.empty()) {
        cout << "Course list is empty. Load data first." << endl;
        return;
    }

    cout << "\nHere is the course list:" << endl;

    for (const auto& pair : courseMap) {
        cout << pair.second.courseNumber
            << ", "
            << pair.second.name
            << endl;
    }
}

// Print individual course details
void PrintCourseInfo(const string& courseNumber) {
    string upperCourse = courseNumber;

    transform(
        upperCourse.begin(),
        upperCourse.end(),
        upperCourse.begin(),
        ::toupper
    );

    auto it = courseMap.find(upperCourse);

    if (it == courseMap.end()) {
        cout << "Course not found." << endl;
        return;
    }

    const Course& course = it->second;

    cout << course.courseNumber
        << ", "
        << course.name
        << endl;

    cout << "Prerequisites: ";

    if (course.prerequisites.empty()) {
        cout << "None" << endl;
    }
    else {
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            cout << course.prerequisites[i];

            if (i < course.prerequisites.size() - 1) {
                cout << ", ";
            }
        }

        cout << endl;
    }
}

// Check that all prerequisites are real courses
bool ValidatePrerequisites() {
    if (courseMap.empty()) {
        cout << "Course list is empty. Load data first." << endl;
        return false;
    }

    bool valid = true;

    for (const auto& pair : courseMap) {
        const Course& course = pair.second;

        for (const string& prerequisite : course.prerequisites) {
            if (courseMap.find(prerequisite) == courseMap.end()) {
                cout << "Invalid prerequisite: "
                    << course.courseNumber
                    << " requires "
                    << prerequisite
                    << ", but that course does not exist."
                    << endl;

                valid = false;
            }
        }
    }

    return valid;
}

// Used to detect circular prerequisites
bool HasCycleDFS(const string& course, map<string, int>& state) {
    // 0 = not visited
    // 1 = currently visiting
    // 2 = completely processed
    state[course] = 1;

    for (const string& dependent : courseGraph[course]) {
        if (state[dependent] == 1) {
            return true;
        }

        if (state[dependent] == 0) {
            if (HasCycleDFS(dependent, state)) {
                return true;
            }
        }
    }

    state[course] = 2;
    return false;
}

// Check for circular prerequisites using DFS
// Time complexity: O(V + E)
bool HasCycle() {
    map<string, int> state;

    for (const auto& pair : courseMap) {
        state[pair.first] = 0;
    }

    for (const auto& pair : courseMap) {
        if (state[pair.first] == 0) {
            if (HasCycleDFS(pair.first, state)) {
                return true;
            }
        }
    }

    return false;
}

// Validate the prerequisite graph
void ValidateCourseGraph() {
    if (courseMap.empty()) {
        cout << "Course list is empty. Load data first." << endl;
        return;
    }

    cout << "\nValidating course prerequisites..." << endl;

    if (!ValidatePrerequisites()) {
        cout << "Course data contains invalid prerequisites." << endl;
        return;
    }

    if (HasCycle()) {
        cout << "Circular prerequisite relationship detected." << endl;
        cout << "The course plan is not valid." << endl;
        return;
    }

    cout << "All prerequisites are valid." << endl;
    cout << "No circular prerequisite relationships were found." << endl;
}

// DFS for the course order
void TopologicalSortDFS(
    const string& course,
    set<string>& visited,
    vector<string>& order
) {
    visited.insert(course);

    for (const string& dependent : courseGraph[course]) {
        if (visited.find(dependent) == visited.end()) {
            TopologicalSortDFS(dependent, visited, order);
        }
    }

    order.push_back(course);
}

// Create a course order with topological sorting
// Time complexity: O(V + E)
void PrintRecommendedCourseOrder() {
    if (courseMap.empty()) {
        cout << "Course list is empty. Load data first." << endl;
        return;
    }

    if (!ValidatePrerequisites()) {
        cout << "Cannot create a course order because invalid prerequisites were found."
            << endl;
        return;
    }

    if (HasCycle()) {
        cout << "Cannot create a course order because a circular prerequisite relationship exists."
            << endl;
        return;
    }

    set<string> visited;
    vector<string> order;

    for (const auto& pair : courseMap) {
        if (visited.find(pair.first) == visited.end()) {
            TopologicalSortDFS(pair.first, visited, order);
        }
    }

    reverse(order.begin(), order.end());

    cout << "\nRecommended Course Order:" << endl;

    int number = 1;

    for (const string& courseNumber : order) {
        const Course& course = courseMap.at(courseNumber);

        cout << number
            << ". "
            << course.courseNumber
            << " - "
            << course.name
            << endl;

        ++number;
    }
}

// Menu
void DisplayMenu() {
    cout << "\n1. Load Course Data" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course Information" << endl;
    cout << "4. Validate Prerequisites" << endl;
    cout << "5. Print Recommended Course Order" << endl;
    cout << "9. Exit" << endl;
    cout << "What would you like to do? ";
}

// Main
int main() {
    cout << "Welcome to the course planner." << endl;

    int choice;
    string input;

    while (true) {
        DisplayMenu();
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');

            cout << "Invalid input. Please enter a number." << endl;
            continue;
        }

        switch (choice) {
        case 1:
            cout << "Enter the file name: ";
            cin >> input;
            LoadDataStructure(input);
            break;

        case 2:
            PrintCourseList();
            break;

        case 3:
            cout << "What course do you want to know about? ";
            cin >> input;
            PrintCourseInfo(input);
            break;

        case 4:
            ValidateCourseGraph();
            break;

        case 5:
            PrintRecommendedCourseOrder();
            break;

        case 9:
            cout << "Thank you for using the course planner!" << endl;
            return 0;

        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }

    return 0;
}