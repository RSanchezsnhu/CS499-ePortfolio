# CS-330
# This is a 3D coffee shop scene showing a coffee cup on a saucer on top of a wooden table. This project was to show how I understand shapes, textures, lighting, camera movement, and scene organization.
# I could not upload the zip file because it was bigger than 25mb and GitHub does not allow files bigger than that.

# How do I approach designing software?
# I think about what the program needs and then break it into smaller parts so its easier to handle and less confusing. For this project I planned everything and how I wanted the scene before starting the code and helped keep everything structured.

# What new design skills did this project help me develop?
# This whole course taught me how to design in 3D spaces. I learned how to create and use lighting, learned about applying textures, learned about sizing objects and shapes and angles to make things more realistic. I also learned camera angles and controls.

# What design process did I follow?
# I planned out how I wanted my scene to look and then focused on implementing that so I wouldnt have to make changes in my head and what I would have to add and do. By doing this I did everything step by step so I can keep track on what I was doing and what gave me errors or just did not look the best visually. I would start on part of the project, make changes, test them, adjust them, add more changes, all until the scene looked how I wanted and worked the way I was satisfied with.

# How can this design approach be used in the future?
# This approach helps me stay organized so I can avoid making mistakes. By breaking things up and keeping things labeled and in small batches of code I can work on testing specific parts of code and it would help me build better software over time.

# How do I approach developing programs?
# I focus on keep my code clean and easy to understand and organize everything so I never repeat the same line of code whenever possible.

# What new development strategies did I use?
# I used functions to handle objects transformations and texture loading which helped make it easier to fix issues since everything was easier to manage.

# How did iteration play a role?
# I spent a lot of time working on object placement and a very long time working and playing with lighting and constantly testing it out. Each small change helped me figure out what worked and what didnt and helped in the end.

# How did my coding approach change over the milestones?
# It became easier to know what I was doing, realized the mistakes I was making, make less mistakes, and helped me learn how to keep my code clean so when I kept adding to the project I would know where everything was and ended up with a plished scene.

# How can computer science help me reach my goals?
# I'm working towards a computer science degree so it has everything to do with what I want

# How do graphics and visualization help in my education?
# Working with graphics showed me how to understand objects and 3D spaces and I saw how fun and rewarding it was to accomplish. This opened my eyes to maybe doing something that has to do with graphics.

# How do graphics and visualization help in my career path?
# It opened my eyes to a new career path I didnt think I was interested in but after doing this course it's made me think about doing something in software or game development.
