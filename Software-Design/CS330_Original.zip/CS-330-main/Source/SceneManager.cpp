﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Modified: (you) - added texture application for mug body and handle
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    // initialize texture count
    m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    // free any OpenGL textures we created
    DestroyGLTextures();

    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // indicate to always flip images vertically when loaded
    stbi_set_flip_vertically_on_load(true);

    // try to parse the image data from the specified image file
    unsigned char* image = stbi_load(
        filename,
        &width,
        &height,
        &colorChannels,
        0);

    // if the image was successfully read from the image file
    if (image)
    {
        std::cout << "Successfully loaded image: " << filename << ", width: " << width << ", height: " << height << ", channels: " << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // set the texture wrapping parameters (tile by default)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // if the loaded image is in RGB format
        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        // if the loaded image is in RGBA format - it supports transparency
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            stbi_image_free(image);
            glBindTexture(GL_TEXTURE_2D, 0);
            return false;
        }

        // generate the texture mipmaps for mapping textures to lower resolutions
        glGenerateMipmap(GL_TEXTURE_2D);

        // free the image data from local memory
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        // register the loaded texture and associate it with the special tag string
        if (m_loadedTextures < 16)
        {
            m_textureIDs[m_loadedTextures].ID = textureID;
            m_textureIDs[m_loadedTextures].tag = tag;
            m_loadedTextures++;
            return true;
        }
        else
        {
            std::cout << "Maximum number of textures (16) reached; cannot load more." << std::endl;
            // delete the texture we created to avoid leak
            glDeleteTextures(1, &textureID);
            return false;
        }
    }

    std::cout << "Could not load image: " << filename << std::endl;

    // Error loading the image
    return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    // Delete any textures we previously generated
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].ID != 0)
        {
            GLuint id = m_textureIDs[i].ID;
            glDeleteTextures(1, &id);
            m_textureIDs[i].ID = 0;
            m_textureIDs[i].tag.clear();
        }
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return(false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.ambientColor = m_objectMaterials[index].ambientColor;
            material.ambientStrength = m_objectMaterials[index].ambientStrength;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    // variables for this method
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    // set the scale value in the transform buffer
    scale = glm::scale(scaleXYZ);
    // set the rotation values in the transform buffer
    rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    // set the translation value in the transform buffer
    translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    // variables for this method
    glm::vec4 currentColor;

    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        // disable texture usage when we want plain color
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 *
 *  This uses the texture slot (0..N) so the shader sampler
 *  is pointed to the correct texture unit.
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        // enable texture usage in the shader
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = -1;
        textureID = FindTextureSlot(textureTag);
        if (textureID >= 0)
        {
            // set the sampler to use the matching texture unit
            // shader expects an integer representing texture unit index
            m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
        }
        else
        {
            // fallback: disable texture if not found
            m_pShaderManager->setIntValue(g_UseTextureName, false);
            std::cout << "Warning: Texture tag not found: " << textureTag << std::endl;
        }
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = false;

        bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
            m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Load meshes
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();

    
    // Load textures
   
    CreateGLTexture("Textures/stone.jpg", "mugBody"); // texture for the cup
    CreateGLTexture("Textures/stone.jpg", "mugHandle"); // texture for the handle
    CreateGLTexture("Textures/coffee.jpg", "coffee"); // texture of the coffee
    CreateGLTexture("Textures/marble.jpg", "plateTexture"); // texture for the plate
    CreateGLTexture("Textures/wood.jpg", "tableTexture"); // texture for the table

    // binds textures
    BindGLTextures();
    SetTextureUVScale(1.0f, 1.0f);

    
    m_objectMaterials.clear();

    OBJECT_MATERIAL mat;
    mat.tag = "default";
    mat.ambientColor = glm::vec3(0.15f);
    mat.ambientStrength = 0.20f;
    mat.diffuseColor = glm::vec3(0.55f);
    mat.specularColor = glm::vec3(0.20f);
    mat.shininess = 8.0f;

    m_objectMaterials.push_back(mat);

    // apply the material once
    SetShaderMaterial("default");

    // enables lighting
    m_pShaderManager->setBoolValue("bUseLighting", true);
    m_pShaderManager->setVec3Value("viewPosition", glm::vec3(0.0f, 5.0f, 12.0f));

  
    // Key Light
    m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(0.0f, 8.0f, 4.0f));
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.06f));
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.28f));
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.20f));
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 20.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.35f);

    // Warm side fill
    m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(3.0f, 4.0f, 2.0f));
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.02f, 0.015f, 0.01f));
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.18f, 0.13f, 0.05f));
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.12f, 0.10f, 0.04f));
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.25f);

    // Blue fill
    m_pShaderManager->setVec3Value("lightSources[2].position", glm::vec3(-2.0f, 3.5f, 1.5f));
    m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.015f, 0.020f, 0.04f));
    m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(0.06f, 0.10f, 0.18f));
    m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(0.04f, 0.06f, 0.10f));
    m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 12.0f);
    m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.20f);

    // Rim light that adds a highlight around the objects
    m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(0.0f, 6.0f, -4.0f));
    m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.01f));
    m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", glm::vec3(0.10f));
    m_pShaderManager->setVec3Value("lightSources[3].specularColor", glm::vec3(0.10f));
    m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 20.0f);
    m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.30f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    float Xrot = 0.0f, Yrot = 0.0f, Zrot = 0.0f;
    glm::vec3 pos;

    
    // TABLE TOP
    
    scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

    pos = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0, 0, 0, pos);

    SetShaderMaterial("default");
    SetShaderTexture("tableTexture");
    SetTextureUVScale(4.0f, 4.0f);

    m_basicMeshes->DrawPlaneMesh();

    
    // SAUCER (tapered cylinder)
    
    scaleXYZ = glm::vec3( 3.0f, -0.6f, 3.0f);
    pos = glm::vec3(0.0f, 0.3f, 0.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, pos);
    SetShaderMaterial("default");
    SetShaderTexture("plateTexture");
    SetTextureUVScale(2.0f, 2.0f);

    m_basicMeshes->DrawTaperedCylinderMesh();

    
    // CUP BODY
    
    float saucerThickness = 0.2f;
    float cupHeight = 2.0f;
    float cupY = saucerThickness + (cupHeight * 0.7f) - 1.3f;

    scaleXYZ = glm::vec3(1.2f, cupHeight, 1.2f);
    pos = glm::vec3(0.0f, cupY, 0.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, pos);
    SetShaderMaterial("default");

    SetShaderTexture("mugBody");
    SetTextureUVScale(4.0f, 1.0f);

    m_basicMeshes->DrawCylinderMesh();

    
    // COFFEE SURFACE
    
    float cupTop = cupY + (cupHeight * 1.0f);
    float coffeeThick = 0.15f;
    float coffeeY = cupTop - (coffeeThick * 0.5f) + 0.1f;

    scaleXYZ = glm::vec3(1.05f, coffeeThick, 1.05f);
    pos = glm::vec3(0.0f, coffeeY, 0.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, pos);
    SetShaderMaterial("default");

    SetShaderTexture("coffee");
    SetTextureUVScale(1.0f, 1.0f);

    m_basicMeshes->DrawCylinderMesh();

    
    // HANDLE (torus)
    
    float handleY = cupY + 1.0f;

    scaleXYZ = glm::vec3(0.6f, 0.6f, 0.6f);
    Xrot = 0.0f; Yrot = 0.0f; Zrot = 90.0f;
    pos = glm::vec3(1.3f, handleY, 0.2f);

    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    SetShaderMaterial("default");

    SetShaderTexture("mugHandle");
    SetTextureUVScale(1.0f, 1.0f);

    m_basicMeshes->DrawTorusMesh();

    // restore shader to non-texture mode
    m_pShaderManager->setIntValue("bUseTexture", false);
}
