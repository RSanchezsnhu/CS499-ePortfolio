from pymongo import MongoClient


class CRUD:
    # connect to the animal database
    def __init__(self, username, password):
        self.client = MongoClient(
            "mongodb://%s:%s@localhost:27017/?authSource=AAC"
            % (username, password)
        )

        self.database = self.client["AAC"]
        self.collection = self.database["animals"]
        # make searches faster
        self.collection.create_index([
            ("animal_type", 1),
            ("breed", 1),
            ("age_upon_outcome_in_weeks", 1)
        ])

    # add a new animal
    def create(self, data):
        if data is not None and isinstance(data, dict):
            result = self.collection.insert_one(data)
            return result.acknowledged

        return False

    # find animals
    def read(self, query):
        if query is None:
            query = {}

        return list(self.collection.find(query))

    # find animals by page
    def read_page(self, query, page, page_size):
        if query is None:
            query = {}

        skip = page * page_size

        return list(
            self.collection.find(query)
            .skip(skip)
            .limit(page_size)
        )

    # count animals
    def count(self, query):
        if query is None:
            query = {}

        return self.collection.count_documents(query)

    # count animals by breed
    def breed_counts(self, query):
        if query is None:
            query = {}

        pipeline = [
            {"$match": query},
            {"$group": {
                "_id": "$breed",
                "count": {"$sum": 1}
            }},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]

        return list(self.collection.aggregate(pipeline))

    # update animal information
    def update(self, query, new_values):
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0

        result = self.collection.update_many(
            query,
            {"$set": new_values}
        )

        return result.modified_count

    # delete animals
    def delete(self, query):
        if not isinstance(query, dict):
            return 0

        result = self.collection.delete_many(query)

        return result.deleted_count