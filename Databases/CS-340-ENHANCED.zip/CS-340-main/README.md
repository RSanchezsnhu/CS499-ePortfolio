# CS-340

# How do you write programs that are maintainable, readable, and adaptable?
# I keep the code organized and separated by responsibility. I did this with the CRUD Python module where it handled all database operations which made it so the dashboard code could be focused on only displaying and filtering data. This made everything easier to test and debug because everything was separated.

# Problem-Solving Approach as a Computer Scientist
# When I do projects I break the project into smaller steps so everything is easier to manage and mistake are easier to find. For this I created and tested the CRUD module to make sure everything worked and connected correctly. I then built the dashboard and connected them to the database. This project had me combine multiple parts of project done throughout the whole course that ended up as a complete system in the end. I would continue doing things as I have for projects like this by planning database queries early, creating reusable modules, and then testing everything before moving on to the next part.

# What do computer scientists do, and why does it matter?
# Solve problems by creating systems that organize, process, and give data in useful ways. This kind of work helps businesses operate smoothly and shows how valuable computer scientists and the work they do are.
